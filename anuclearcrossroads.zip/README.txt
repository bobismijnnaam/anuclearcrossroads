A NUCLEAR CROSSROADS
====================
After saving your village from the malicious poaching Major, you got an important job as the Button Keeper at the Manhattan Group. Your first days of work seem to be fine, but as the people of the city get restless a slumbering danger approaches.

Relevant XKCD: https://xkcd.com/898/

HOW TO PLAY
===========
It's a point and click game. So use your mouse and brains, and watch carefully how the game responds to your input!

ABOUT THE GAME
==============
"A NUCLEAR CROSSROADS" is a game made for Ludum Dare 32 by Bob Rubbens [http://plusminos.nl | @broervanlisa | bobrubbens at gmail]. It was made in 48 hours with SDL2, my Nuts 'n Bolts games framework and lots of love (and cafeine-induced stress)!

CREDITS
=======
I made assets and code myself, used Nuts 'n Bolts as a framework, and included licenses for the stuff I got from the internet. These are only fonts/libraries though (json in particular - it saved my day) so it should be fine. 

Michiel Bakker - kroketteh

Check out my blog [http://blog.plusminos.nl] for a timelapse of this jam!
